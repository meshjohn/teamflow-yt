<img width="1919" height="989" alt="screenshot-dark" src="https://gist.github.com/user-attachments/assets/f33d9916-d3dd-44df-85f4-1d822e86e8e8" />
<img width="1919" height="989" alt="screenshot-light" src="https://gist.github.com/user-attachments/assets/4b8e3c9d-4d48-47e3-8ffd-ce3e1253edcb" />
