<img width="1024" height="290" alt="prisma" src="https://gist.github.com/user-attachments/assets/d88b8813-fbb0-4edf-8221-a9f0f7a6989f" />
