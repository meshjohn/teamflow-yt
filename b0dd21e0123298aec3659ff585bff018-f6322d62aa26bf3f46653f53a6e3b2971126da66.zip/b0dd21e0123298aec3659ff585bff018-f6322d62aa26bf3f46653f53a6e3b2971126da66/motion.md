<img width="1024" height="393" alt="motion-logo" src="https://gist.github.com/user-attachments/assets/5e44bc91-3df0-4ad0-87a1-cb4c059cc93c" />
