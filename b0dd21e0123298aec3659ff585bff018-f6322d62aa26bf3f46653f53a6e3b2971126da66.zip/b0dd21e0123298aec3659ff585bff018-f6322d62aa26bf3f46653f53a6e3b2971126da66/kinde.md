<img width="600" height="199" alt="kinde" src="https://gist.github.com/user-attachments/assets/cf153fae-178a-4c83-aef5-1a8ba2e6f867" />
