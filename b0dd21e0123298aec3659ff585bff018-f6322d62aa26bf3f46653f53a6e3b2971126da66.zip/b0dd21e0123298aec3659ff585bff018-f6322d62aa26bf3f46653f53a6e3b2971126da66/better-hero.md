<img width="1921" height="989" alt="better-hero-dark" src="https://gist.github.com/user-attachments/assets/ff7d41b8-9af0-4926-9ba3-c847229b9ffd" />
