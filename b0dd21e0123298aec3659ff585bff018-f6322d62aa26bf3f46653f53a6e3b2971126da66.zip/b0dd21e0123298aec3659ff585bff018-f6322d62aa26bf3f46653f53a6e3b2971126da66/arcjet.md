<img width="1040" height="370" alt="arcjet" src="https://gist.github.com/user-attachments/assets/0f5037c8-b012-4602-b94c-5805b6bd3c73" />
